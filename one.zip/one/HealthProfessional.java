package one;

import java.io.Serializable;
import java.util.Objects;

/**
 * Represents a health professional such as a doctor, nurse, or surgeon.
 * Each professional has a name, medical profession, and workplace location.
 *
 * This class is used to associate appointments with the professionals
 * responsible for the medical procedures. It implements {@link Serializable}
 * to support saving and restoring objects from persistent storage.
 */
public class HealthProfessional implements Serializable {

    /** The full name of the health professional. */
    private String name;

    /** The profession or role . */
    private String profession;

    /** The hospital or clinic location where the professional works. */
    private String location;

    /**
     * Constructs a new health professional with the given name, profession, and location.
     *
     * @param name       the full name of the professional
     * @param profession the role or specialization
     * @param location   the hospital or clinic location
     */
    public HealthProfessional(String name, String profession, String location) 
    {
        this.name = name;
        this.profession = profession;
        this.location = location;
    }

    /** @return the name of the health professional */
    public String getName() 
    {
        return name;
    }

    /** @return the medical profession or role */
    public String getProfession() 
    {
        return profession;
    }

    /** @return the location where the professional works */
    public String getLocation() 
    {
        return location;
    }

    /**
     * Updates the name of the professional.
     * @param name the new name
     */
    public void setName(String name) 
    {
        this.name = name;
    }

    /**
     * Updates the profession or specialisation.
     * @param profession the new profession
     */
    public void setProfession(String profession) 
    {
        this.profession = profession;
    }

    /**
     * Updates the location where the professional works.
     * @param location the new location
     */
    public void setLocation(String location) 
    {
        this.location = location;
    }

    /**
     * Returns a string representation of the health professional, useful for debugging or UI display.
     */
    @Override
    public String toString() 
    {
        return "HealthProfessional{" +
               "name='" + name + '\'' +
               ", profession='" + profession + '\'' +
               ", location='" + location + '\'' +
               '}';
    }

    /**
     * Defines equality based on name, profession, and location.
     *
     * @param o the other object to compare
     * @return true if this and the other object represent the same professional
     */
    @Override
    public boolean equals(Object o) 
    {
        if (this == o) return true;
        if (!(o instanceof HealthProfessional)) return false;
        HealthProfessional that = (HealthProfessional) o;
        return Objects.equals(name, that.name) &&
               Objects.equals(profession, that.profession) &&
               Objects.equals(location, that.location);
    }

    /**
     * Generates a hash code using name, profession, and location.
     * @return the hash code
     */
    @Override
    public int hashCode() 
    {
        return Objects.hash(name, profession, location);
    }
}
