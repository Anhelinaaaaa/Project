package one;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;
import java.util.stream.Collectors;

/**
 * Diary stores and manages a list of appointments for a health professional.
 * Supports operations such as add, edit, remove, filter, undo, and conflict checking.
 */
public class Diary implements Serializable {

    /** The list of appointments assigned to this diary */
    private List<Appointment> appointments;

    /** A stack to support undo functionality by storing previous appointment states */
    private Stack<List<Appointment>> undoStack;

    /** Constructs an empty diary */
    public Diary() {
        this.appointments = new ArrayList<>();
        this.undoStack = new Stack<>();
    }

    /**
     * Saves the current list of appointments to the undo stack
     * to allow reverting in case of undo
     */
    private void saveStateForUndo() {
        undoStack.push(new ArrayList<>(appointments));
    }

    /**
     * Adds an appointment if it does not overlap with existing ones
     *
     * @param appointment the appointment to add
     * @return true if added successfully, false if it conflicts
     */
    public boolean addAppointment(Appointment appointment) {
        if (isOverlapping(appointment)) {
            System.out.println("Appointment conflicts with an existing one.");
            return false;
        }
        saveStateForUndo();
        appointments.add(appointment);
        return true;
    }

    /**
     * Removes an appointment if it exists
     *
     * @param appointment the appointment to remove
     * @return true if successfully removed, false if not found
     */
    public boolean removeAppointment(Appointment appointment) {
        if (appointments.contains(appointment)) {
            saveStateForUndo();
            appointments.remove(appointment);
            return true;
        }
        return false;
    }

    /**
     * Replaces an existing appointment with a new one if the new one does not overlap
     *
     * @param oldApp the existing appointment to replace
     * @param newApp the new appointment to insert
     * @return true if edited successfully, false on conflict or not found
     */
    public boolean editAppointment(Appointment oldApp, Appointment newApp) {
        int index = appointments.indexOf(oldApp);
        if (index != -1 && !isOverlapping(newApp)) {
            saveStateForUndo();
            appointments.set(index, newApp);
            return true;
        }
        System.out.println("Cannot edit: New appointment conflicts with existing ones.");
        return false;
    }

    /**
     * Returns a copy of all appointments in the diary
     *
     * @return list of all appointments
     */
    public List<Appointment> getAppointments() {
        return new ArrayList<>(appointments);
    }

    /**
     * Returns appointments scheduled on a specific date
     *
     * @param date the target date
     * @return list of appointments on that date
     */
    public List<Appointment> getAppointmentsOnDate(LocalDate date) {
        return appointments.stream()
                .filter(app -> app.getDate().equals(date))
                .collect(Collectors.toList());
    }

    /**
     * Filters appointments by treatment type (case-insensitive)
     *
     * @param treatmentType the treatment type to match
     * @return list of matching appointments
     */
    public List<Appointment> filterByTreatmentType(String treatmentType) {
        return appointments.stream()
                .filter(app -> app.getTreatmentType().equalsIgnoreCase(treatmentType))
                .collect(Collectors.toList());
    }

    /**
     * Filters appointments involving a specific doctor
     *
     * @param doctorName the name of the doctor
     * @return list of appointments where the doctor is assigned
     */
    public List<Appointment> filterByDoctor(String doctorName) {
        return appointments.stream()
                .filter(app -> app.getDoctors().stream()
                        .anyMatch(d -> d.getName().equalsIgnoreCase(doctorName)))
                .collect(Collectors.toList());
    }

    /**
     * Checks if a new appointment overlaps with any existing ones
     *
     * @param newAppointment the appointment to check
     * @return true if it overlaps, false otherwise
     */
    public boolean isOverlapping(Appointment newAppointment) {
        return appointments.stream().anyMatch(existing ->
            newAppointment.getDate().equals(existing.getDate()) &&
            !(newAppointment.getEndTime().isBefore(existing.getStartTime()) ||
              newAppointment.getStartTime().isAfter(existing.getEndTime()))
        );
    }

    /**
     * Restores the previous appointment list state (undo last operation)
     *
     * @return true if undo was successful, false if no previous state exists
     */
    public boolean undo() {
        if (!undoStack.isEmpty()) {
            appointments = undoStack.pop();
            return true;
        }
        return false;
    }

    /**
     * Prints all appointments to the console
     */
    public void printAllAppointments() {
        if (appointments.isEmpty()) {
            System.out.println("No appointments.");
        } else {
            appointments.forEach(System.out::println);
        }
    }
}

