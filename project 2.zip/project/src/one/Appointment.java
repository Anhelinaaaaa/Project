package one;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Objects;

/**
 * Represents a patient appointment involving one or more health professionals.
 * Stores the date, time range, treatment type, assigned doctors, and patient ID.
 */
public class Appointment implements Serializable {

    /** The date of the appointment. */
    private LocalDate date;

    /** The starting time of the appointment. */
    private LocalTime startTime;

    /** The ending time of the appointment. */
    private LocalTime endTime;

    /** The type of treatment or procedure for the appointment. */
    private String treatmentType;

    /** The list of health professionals assigned to this appointment. */
    private List<HealthProfessional> doctors;

    /** The identifier of the patient receiving the treatment. */
    private String patientId;

    /**
     * Constructs an Appointment with specified date, time range, treatment type,
     * doctors involved, and patient ID.
     *
     * @param date          the appointment date
     * @param startTime     the start time
     * @param endTime       the end time
     * @param treatmentType the treatment description
     * @param doctors       the list of assigned health professionals
     * @param patientId     the patient's ID
     */
    public Appointment(LocalDate date, LocalTime startTime, LocalTime endTime,
                       String treatmentType, List<HealthProfessional> doctors, String patientId) {
        this.date = date;
        this.startTime = startTime;
        this.endTime = endTime;
        this.treatmentType = treatmentType;
        this.doctors = doctors;
        this.patientId = patientId;
    }

    /** @return the date of the appointment */
    public LocalDate getDate() 
    {
        return date;
    }

    /** @return the start time of the appointment */
    public LocalTime getStartTime() 
    {
        return startTime;
    }

    /** @return the end time of the appointment */
    public LocalTime getEndTime() 
    {
        return endTime;
    }

    /** @return the treatment type or procedure */
    public String getTreatmentType() 
    {
        return treatmentType;
    }

    /** @return the patient ID */
    public String getPatientId() 
    {
        return patientId;
    }

    /** @return the list of health professionals for this appointment */
    public List<HealthProfessional> getDoctors() 
    {
        return doctors;
    }

    /**
     * Sets the date of the appointment.
     * @param date the new date
     */
    public void setDate(LocalDate date) 
    {
        this.date = date;
    }

    /**
     * Sets the start time of the appointment.
     * @param startTime the new start time
     */
    public void setStartTime(LocalTime startTime) 
    {
        this.startTime = startTime;
    }

    /**
     * Sets the end time of the appointment.
     * @param endTime the new end time
     */
    public void setEndTime(LocalTime endTime) 
    {
        this.endTime = endTime;
    }

    /**
     * Sets the treatment type of the appointment.
     * @param treatmentType the new treatment type
     */
    public void setTreatmentType(String treatmentType) 
    {
        this.treatmentType = treatmentType;
    }

    /**
     * Sets the patient ID.
     * @param patientId the new patient ID
     */
    public void setPatientId(String patientId) 
    {
        this.patientId = patientId;
    }

    /**
     * Sets the list of health professionals assigned to the appointment.
     * @param doctors the new doctor list
     */
    public void setDoctors(List<HealthProfessional> doctors) 
    {
        this.doctors = doctors;
    }

    /**
     * Returns a string representation of the appointment, useful for display.
     */
    @Override
    public String toString() 
    {
        return "Appointment{" +
                "date=" + date +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", treatmentType='" + treatmentType + '\'' +
                ", patientId='" + patientId + '\'' +
                ", doctors=" + doctors +
                '}';
    }

    /**
     * Defines equality based on date, time, treatment type, and doctors.
     */
    @Override
    public boolean equals(Object o) 
    {
        if (this == o) return true;
        if (!(o instanceof Appointment)) return false;
        Appointment that = (Appointment) o;
        return Objects.equals(date, that.date) &&
               Objects.equals(startTime, that.startTime) &&
               Objects.equals(endTime, that.endTime) &&
               Objects.equals(treatmentType, that.treatmentType) &&
               Objects.equals(doctors, that.doctors);
    }

    /**
     * Hash code is based on date, time, treatment type, and doctors.
     */
    @Override
    public int hashCode() 
    {
        return Objects.hash(date, startTime, endTime, treatmentType, doctors);
    }
}

